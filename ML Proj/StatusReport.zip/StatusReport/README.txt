TITANIC : MACHINE LEARNIG FROM DISASTER
INITIAL STATUS REPORT

TEAM: 
1. ESWAR CHOWDARY GANTA (exg151430)
2. DILEEP GUDENA (dxg161730)
3. DIVYA REDDY VUDEM (dxv151430)
4. SAI CHARAN RAO VENNAMANANI (sxv157130)
5. SANTHOSH KAMISHETTY (sxk165130)
__________________________________________________________________

1. This is just a description of how we proceed about the project.
2. The included code does basic preprocessing, which will be refined further.
